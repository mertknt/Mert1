
import React, { useState } from "react";
import ReactDOM from "react-dom";

const App = () => {
  return <div className="text-center text-xl">Language Learning App</div>;
};

ReactDOM.render(<App />, document.getElementById("app"));
    